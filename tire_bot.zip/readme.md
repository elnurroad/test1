# Təkər Naxış Botu

Bu bot Telegram üzərindən təkər naxış kodlarını qəbul edib müvafiq şəkli göndərir.

## Quraşdırma

1. `TELEGRAM_TOKEN` mühit dəyişənini təyin edin.
2. `images/` qovluğuna PNG formatında şəkilləri yerləşdirin. Fayl adları naxış kodu ilə eyni olmalıdır. Məsələn: `KNK50.png`
3. `python main.py` əmrini işə salın.